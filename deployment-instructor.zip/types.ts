
export interface Task {
  id: string;
  title: string;
  description: string;
  steps: string[];
  status: 'pending' | 'in-progress' | 'completed';
}

export interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
}

export interface ConfigTemplate {
  name: string;
  filename: string;
  content: string;
  type: 'env' | 'yaml' | 'json' | 'docker';
}
