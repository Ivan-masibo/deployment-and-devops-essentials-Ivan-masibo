
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const getDevOpsAdvice = async (prompt: string, history: { role: 'user' | 'assistant', content: string }[]) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: [
        {
          role: 'user',
          parts: [{ text: "You are a world-class DevOps and Full-stack engineer helping a student with their MERN + Next.js deployment assignment. Provide clear, technical, and encouraging advice regarding CI/CD, production optimization, Next.js Server Components, SSR, and cloud hosting on platforms like Vercel and Render." }]
        },
        ...history.map(h => ({
          role: h.role === 'assistant' ? 'model' : 'user',
          parts: [{ text: h.content }]
        })),
        {
          role: 'user',
          parts: [{ text: prompt }]
        }
      ],
      config: {
        temperature: 0.7,
        topP: 0.9,
      }
    });

    return response.text;
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "I'm sorry, I encountered an error while trying to process your request. Please ensure your API key is valid.";
  }
};
