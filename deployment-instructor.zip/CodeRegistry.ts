
export const BOILERPLATE_CODE = {
  nextConfig: {
    filename: 'next.config.js',
    content: `/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  images: {
    domains: ['res.cloudinary.com', 'images.unsplash.com'],
  },
  // 1. Performance: Enable experimental features for better SEO
  experimental: {
    optimizePackageImports: ['lucide-react'],
  },
  // 2. Deployment: Custom headers for security
  async headers() {
    return [
      {
        source: '/(.*)',
        headers: [
          { key: 'X-Content-Type-Options', value: 'nosniff' },
          { key: 'X-Frame-Options', value: 'DENY' },
          { key: 'X-XSS-Protection', value: '1; mode=block' },
        ],
      },
    ];
  },
};

module.exports = nextConfig;`
  },
  nextLayout: {
    filename: 'app/layout.tsx',
    content: `import { Metadata } from 'next';
import './globals.css';

// 3. SEO: Leveraging Next.js Metadata API
export const metadata: Metadata = {
  title: 'MERN TaskFlow | Productive Workflow',
  description: 'Manage your tasks with real-time sync and high performance SSR.',
  openGraph: {
    title: 'MERN TaskFlow',
    description: 'The ultimate MERN + Next.js productivity tool.',
    url: 'https://taskflow.pro',
    siteName: 'TaskFlow',
    images: [{ url: '/og-image.png' }],
    locale: 'en_US',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'MERN TaskFlow',
    description: 'Built with Next.js 14 for maximum speed.',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}`
  },
  backend: {
    filename: 'server.js',
    content: `const express = require('express');
const mongoose = require('mongoose');
const helmet = require('helmet');
const cors = require('cors');
const morgan = require('morgan');
const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const app = express();

// 1. Security Headers (Task 1)
app.use(helmet());

// 2. CORS Configuration for Next.js (Task 2)
app.use(cors({
  origin: process.env.CLIENT_URL || 'http://localhost:3000',
  credentials: true
}));

// 3. Detailed Request Logging (Updated)
// Configurable via MORGAN_FORMAT environment variable.
// Defaults to 'combined' in production for detailed logs including user-agent and IP.
const morganFormat = process.env.MORGAN_FORMAT || (process.env.NODE_ENV === 'production' ? 'combined' : 'dev');
app.use(morgan(morganFormat, {
  skip: (req, res) => process.env.NODE_ENV === 'production' && res.statusCode < 400 && !process.env.LOG_ALL
}));

app.use(express.json());

// 4. Supabase Integration (New)
const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_ANON_KEY
);

// 5. Health Check Endpoint (Task 5)
app.get('/health', async (req, res) => {
  const mongoStatus = mongoose.connection.readyState === 1 ? 'OK' : 'ERROR';
  res.status(200).json({ 
    status: 'UP', 
    timestamp: new Date(),
    databases: {
      mongodb: mongoStatus,
      supabase: 'CONNECTED' // Usually checked via a simple query
    }
  });
});

// 6. Optimized MongoDB Pooling (Task 1)
const MONGODB_URI = process.env.MONGODB_URI;
mongoose.connect(MONGODB_URI, {
  maxPoolSize: 10, 
  serverSelectionTimeoutMS: 5000,
}).then(() => console.log('✅ MongoDB Ready'))
  .catch(err => console.error('❌ Connection Error:', err));

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(\`🚀 Backend on \${PORT} in \${process.env.NODE_ENV} mode\`));`
  },
  supabaseConfig: {
    filename: '.env.example',
    content: `# --- Server Config ---
NODE_ENV=production
PORT=5000
MORGAN_FORMAT=combined
LOG_ALL=false

# --- Database Config ---
MONGODB_URI=mongodb+srv://user:pass@cluster.mongodb.net/dbname
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_ANON_KEY=your-anon-key

# --- Client Config ---
CLIENT_URL=https://your-frontend.vercel.app`
  },
  cicd: {
    filename: 'vercel-deploy.yml',
    content: `name: Vercel Production Deployment
on:
  push:
    branches: [ main ]
jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Install Vercel CLI
        run: npm install --global vercel
      - name: Pull Vercel Environment Information
        run: vercel pull --yes --environment=production --token=\${{ secrets.VERCEL_TOKEN }}
      - name: Build Project Artifacts
        run: vercel build --prod --token=\${{ secrets.VERCEL_TOKEN }}
      - name: Deploy Project Artifacts to Vercel
        run: vercel deploy --prebuilt --prod --token=\${{ secrets.VERCEL_TOKEN }}`
  }
};
