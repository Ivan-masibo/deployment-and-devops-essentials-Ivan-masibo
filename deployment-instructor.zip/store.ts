
import { create } from 'zustand';
import { Task, ChatMessage } from './types';

const INITIAL_TASKS: Task[] = [
  {
    id: 't1',
    title: 'Phase 1: Next.js & Backend Optimization',
    description: 'Transition to Next.js for the frontend and optimize the Express/MongoDB layer.',
    status: 'pending',
    steps: [
      'Integrate Next.js App Router for enhanced routing and SEO',
      'Implement centralized state management using Zustand for predictable UI flow',
      'Configure environment variables for Next.js (NEXT_PUBLIC_) and Express',
      'Implement secure HTTP headers using Helmet.js on the backend',
      'Set up production-ready logging using Morgan',
      'Optimize MongoDB Atlas connection pooling for Serverless/Node environments'
    ]
  },
  {
    id: 't2',
    title: 'Phase 2: Hybrid Infrastructure',
    description: 'Architect a hosting strategy with Vercel (Frontend/Next.js) and Render (API).',
    status: 'pending',
    steps: [
      'Deploy Next.js frontend to Vercel for Edge Network performance',
      'Provision Express backend services on Render/Railway',
      'Configure Image Optimization and ISR (Incremental Static Regeneration)',
      'Manage Cross-Origin Resource Sharing (CORS) between Next.js and API',
      'Verify SSL termination and HTTPS redirect rules for both domains'
    ]
  },
  {
    id: 't3',
    title: 'Phase 3: High-Velocity CI/CD',
    description: 'Build industrial-grade automated pipelines for Next.js deployments.',
    status: 'pending',
    steps: [
      'Design .github/workflows/main.yml with build-caching for Next.js',
      'Configure auto-linting and automated unit testing (Vitest/Jest)',
      'Define staging (Preview) and production deployment branches',
      'Secure production secrets in Vercel and GitHub repository settings'
    ]
  },
  {
    id: 't4',
    title: 'Phase 4: Observability & SEO',
    description: 'Ensure your application is healthy, discoverable, and performant.',
    status: 'pending',
    steps: [
      'Architect a dedicated /api/health route in Next.js and Express',
      'Initialize Sentry.io SDK for full-stack crash reporting',
      'Configure Next.js Metadata API for optimized SEO and Social Sharing',
      'Establish a formal incident response and automated rollback plan'
    ]
  }
];

export type TaskFilter = 'all' | 'pending' | 'in-progress' | 'completed';

interface AppState {
  tasks: Task[];
  activeTab: 'dashboard' | 'code' | 'chat';
  activeTask: Task | null;
  chatHistory: ChatMessage[];
  isTyping: boolean;
  backendStatus: 'online' | 'offline' | 'checking';
  filter: TaskFilter;
  
  // Actions
  toggleTask: (taskId: string) => void;
  updateTaskStatus: (taskId: string, status: Task['status']) => void;
  setActiveTab: (tab: 'dashboard' | 'code' | 'chat') => void;
  setActiveTask: (task: Task | null) => void;
  addChatMessage: (msg: ChatMessage) => void;
  setIsTyping: (val: boolean) => void;
  setBackendStatus: (status: 'online' | 'offline' | 'checking') => void;
  setFilter: (filter: TaskFilter) => void;
  getProgress: () => number;
}

export const useStore = create<AppState>((set, get) => ({
  tasks: INITIAL_TASKS,
  activeTab: 'dashboard',
  activeTask: null,
  chatHistory: [],
  isTyping: false,
  backendStatus: 'checking',
  filter: 'all',

  toggleTask: (taskId: string) => set((state) => ({
    tasks: state.tasks.map(t => {
      if (t.id === taskId) {
        const nextStatus: Task['status'] = t.status === 'completed' ? 'pending' : 'completed';
        return { ...t, status: nextStatus };
      }
      return t;
    })
  })),

  updateTaskStatus: (taskId: string, status: Task['status']) => set((state) => ({
    tasks: state.tasks.map(t => t.id === taskId ? { ...t, status } : t)
  })),

  setActiveTab: (tab) => set({ activeTab: tab }),
  
  setActiveTask: (task) => set({ activeTask: task }),

  addChatMessage: (msg) => set((state) => ({ 
    chatHistory: [...state.chatHistory, msg] 
  })),

  setIsTyping: (val) => set({ isTyping: val }),

  setBackendStatus: (status) => set({ backendStatus: status }),

  setFilter: (filter) => set({ filter }),

  getProgress: () => {
    const tasks = get().tasks;
    return (tasks.filter(t => t.status === 'completed').length / tasks.length) * 100;
  }
}));
