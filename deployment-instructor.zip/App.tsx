
import React, { useState, useEffect } from 'react';
import { 
  Rocket, 
  ShieldCheck, 
  Layout, 
  ChevronRight, 
  CheckCircle2, 
  Circle,
  MessageSquare,
  FileCode,
  AlertTriangle,
  ExternalLink,
  Terminal as TerminalIcon,
  Code2,
  Copy,
  Check,
  Cpu,
  Globe,
  Settings,
  Search,
  Wifi,
  WifiOff,
  Clock,
  Filter
} from 'lucide-react';
import { ChatMessage, Task } from './types';
import { getDevOpsAdvice } from './geminiService';
import { BOILERPLATE_CODE } from './CodeRegistry';
import { useStore, TaskFilter } from './store';

export default function App() {
  // Use global store state
  const { 
    tasks, 
    activeTab, 
    activeTask, 
    chatHistory, 
    isTyping, 
    backendStatus,
    filter,
    toggleTask,
    updateTaskStatus,
    setActiveTab,
    setActiveTask,
    addChatMessage,
    setIsTyping,
    setBackendStatus,
    setFilter,
    getProgress
  } = useStore();

  const [userInput, setUserInput] = useState('');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // Polling backend health status
  useEffect(() => {
    const checkHealth = async () => {
      try {
        const response = await fetch('/health');
        if (response.ok) {
          setBackendStatus('online');
        } else {
          setBackendStatus('offline');
        }
      } catch (error) {
        setBackendStatus('offline');
      }
    };

    checkHealth();
    const interval = setInterval(checkHealth, 30000); // Poll every 30 seconds
    return () => clearInterval(interval);
  }, [setBackendStatus]);

  const handleSendMessage = async () => {
    if (!userInput.trim()) return;
    const userMsg: ChatMessage = { role: 'user', content: userInput };
    addChatMessage(userMsg);
    setUserInput('');
    setIsTyping(true);
    
    // Get full updated history for the AI
    const updatedHistory = [...chatHistory, userMsg];
    const advice = await getDevOpsAdvice(userInput, updatedHistory);
    
    addChatMessage({ role: 'assistant', content: advice });
    setIsTyping(false);
  };

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const progress = getProgress();

  const filteredTasks = tasks.filter(t => filter === 'all' || t.status === filter);

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 font-['Inter']">
      {/* Global Header */}
      <header className="glass-header border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-indigo-600 p-2.5 rounded-xl shadow-lg shadow-indigo-100">
              <Cpu className="text-white w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-bold text-lg leading-tight text-slate-900">Deployment Instructor</h1>
                <div className={`flex items-center gap-1.5 px-2 py-0.5 rounded-full border text-[10px] font-bold uppercase tracking-tight transition-colors ${
                  backendStatus === 'online' 
                    ? 'bg-emerald-50 text-emerald-600 border-emerald-100' 
                    : backendStatus === 'offline' 
                    ? 'bg-rose-50 text-rose-600 border-rose-100' 
                    : 'bg-slate-50 text-slate-500 border-slate-100'
                }`}>
                  {backendStatus === 'online' ? <Wifi className="w-2.5 h-2.5" /> : <WifiOff className="w-2.5 h-2.5" />}
                  {backendStatus === 'online' ? 'API Online' : backendStatus === 'offline' ? 'API Offline' : 'Syncing...'}
                </div>
              </div>
              <p className="text-[10px] text-indigo-600 font-bold tracking-widest uppercase">MERN + Next.js Lab</p>
            </div>
          </div>
          
          <nav className="flex gap-1 bg-slate-100/50 p-1 rounded-xl border border-slate-200">
            {[
              { id: 'dashboard', icon: Layout, label: 'Curriculum' },
              { id: 'code', icon: Code2, label: 'Boilerplates' },
              { id: 'chat', icon: MessageSquare, label: 'AI Instructor' }
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-4 py-1.5 rounded-lg text-sm font-semibold transition-all ${
                  activeTab === tab.id ? 'bg-white text-indigo-600 shadow-sm border border-slate-100' : 'text-slate-500 hover:text-slate-700'
                }`}
              >
                <tab.icon className="w-4 h-4" />
                <span className="hidden md:inline">{tab.label}</span>
              </button>
            ))}
          </nav>
        </div>
      </header>

      <main className="flex-1 max-w-7xl mx-auto w-full p-4 lg:p-8 animate-fade-in">
        {activeTab === 'dashboard' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            {/* Sidebar Stats & Filtering */}
            <div className="lg:col-span-4 space-y-6">
              <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm instructor-card">
                <div className="flex items-center justify-between mb-2">
                  <h2 className="font-bold text-slate-800">Bootcamp Completion</h2>
                  <span className="text-indigo-600 font-bold text-sm bg-indigo-50 px-2 py-0.5 rounded">{Math.round(progress)}%</span>
                </div>
                <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden mb-6">
                  <div className="h-full bg-indigo-600 transition-all duration-1000 ease-out" style={{ width: `${progress}%` }} />
                </div>
                
                {/* Status Filter Tabs */}
                <div className="mb-4 pb-4 border-b border-slate-100">
                  <div className="flex items-center gap-2 mb-3">
                    <Filter className="w-3.5 h-3.5 text-slate-400" />
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Filter Modules</span>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {(['all', 'pending', 'in-progress', 'completed'] as TaskFilter[]).map((f) => (
                      <button
                        key={f}
                        onClick={() => setFilter(f)}
                        className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition-all border ${
                          filter === f 
                            ? 'bg-indigo-600 border-indigo-600 text-white shadow-md shadow-indigo-100' 
                            : 'bg-white border-slate-200 text-slate-500 hover:border-indigo-300 hover:text-indigo-600'
                        }`}
                      >
                        {f.charAt(0).toUpperCase() + f.slice(1)}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  {filteredTasks.length > 0 ? (
                    filteredTasks.map(task => (
                      <div 
                        key={task.id} 
                        onClick={() => setActiveTask(task)}
                        className={`p-3 rounded-xl border flex items-center gap-3 cursor-pointer transition-all ${
                          activeTask?.id === task.id ? 'border-indigo-600 bg-indigo-50/50 shadow-inner' : 'border-slate-50 hover:border-slate-200 hover:bg-slate-50/50'
                        }`}
                      >
                        {task.status === 'completed' ? (
                          <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                        ) : task.status === 'in-progress' ? (
                          <Clock className="w-5 h-5 text-amber-500" />
                        ) : (
                          <Circle className="w-5 h-5 text-slate-300" />
                        )}
                        <span className={`text-sm font-semibold truncate ${task.status === 'completed' ? 'text-slate-400' : 'text-slate-700'}`}>
                          {task.title}
                        </span>
                      </div>
                    ))
                  ) : (
                    <div className="py-8 text-center px-4">
                      <p className="text-xs font-medium text-slate-400">No phases found with status "{filter}".</p>
                    </div>
                  )}
                </div>
              </div>

              {/* Terminal Preview */}
              <div className="terminal-container p-5 text-white overflow-hidden relative group">
                <div className="flex gap-1.5 mb-4">
                  <div className="w-2.5 h-2.5 rounded-full bg-rose-500/80" />
                  <div className="w-2.5 h-2.5 rounded-full bg-amber-500/80" />
                  <div className="w-2.5 h-2.5 rounded-full bg-emerald-500/80" />
                </div>
                <h3 className="font-bold text-xs mb-3 flex items-center gap-2 text-slate-400">
                  <TerminalIcon className="w-3 h-3" />
                  STDOUT PIPELINE
                </h3>
                <div className="font-mono text-[10px] space-y-1.5 text-slate-400 custom-scrollbar overflow-y-auto h-32">
                  <p className="text-emerald-400 flex gap-2"><span>[INFO]</span> <span>Next.js Build: Collecting page data...</span></p>
                  <p className="flex gap-2"><span>[INFO]</span> <span>Generating static pages (ISR/SSG)...</span></p>
                  <p className="flex gap-2 text-blue-400"><span>[DEBUG]</span> <span>SSR Hydration check: PASS</span></p>
                  <p className="flex gap-2 text-indigo-400"><span>[STATE]</span> <span>Zustand store initialized successfully</span></p>
                  <p className="flex gap-2"><span>[WARN]</span> <span>NEXT_PUBLIC_API_URL should use HTTPS in production</span></p>
                  <p className="text-emerald-400 flex gap-2"><span>[INFO]</span> <span>Vercel Edge Network: SYNCED</span></p>
                </div>
              </div>
            </div>

            {/* Task Content */}
            <div className="lg:col-span-8">
              {activeTask ? (
                <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden animate-slide-up">
                  <div className="p-8 border-b border-slate-100 bg-slate-50/30">
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-6">
                      <div>
                        <div className="flex items-center gap-2 mb-2">
                          <span className="text-[10px] font-black bg-indigo-600 text-white px-2 py-0.5 rounded uppercase tracking-tighter">Module ACTIVE</span>
                        </div>
                        <h2 className="text-3xl font-bold text-slate-900 tracking-tight">{activeTask.title}</h2>
                        <p className="text-slate-500 mt-2 text-lg max-w-xl leading-relaxed">{activeTask.description}</p>
                      </div>
                      <div className="flex flex-col gap-2 shrink-0">
                         <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest text-center">Update Status</span>
                         <div className="flex bg-slate-100 p-1 rounded-xl gap-1">
                            {[
                              { s: 'pending', icon: Circle, color: 'text-slate-500' },
                              { s: 'in-progress', icon: Clock, color: 'text-amber-500' },
                              { s: 'completed', icon: CheckCircle2, color: 'text-emerald-500' }
                            ].map(({ s, icon: Icon, color }) => (
                              <button
                                key={s}
                                onClick={() => updateTaskStatus(activeTask.id, s as Task['status'])}
                                title={s.replace('-', ' ')}
                                className={`p-2 rounded-lg transition-all ${
                                  activeTask.status === s 
                                    ? 'bg-white shadow-sm ring-1 ring-slate-200' 
                                    : 'hover:bg-slate-200'
                                }`}
                              >
                                <Icon className={`w-5 h-5 ${activeTask.status === s ? color : 'text-slate-400'}`} />
                              </button>
                            ))}
                         </div>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-10 mt-10">
                      <div>
                        <h4 className="font-bold text-slate-800 text-xs uppercase tracking-widest mb-6 border-b border-slate-100 pb-2">Technical Requirements</h4>
                        <div className="space-y-5">
                          {activeTask.steps.map((step, i) => (
                            <div key={i} className="flex gap-4 group">
                              <div className="step-number w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold shrink-0 shadow-sm">
                                {i + 1}
                              </div>
                              <p className="text-slate-600 text-sm leading-relaxed group-hover:text-slate-900 transition-colors">{step}</p>
                            </div>
                          ))}
                        </div>
                      </div>
                      
                      <div className="space-y-6">
                        <div className="bg-indigo-50 border border-indigo-200 p-5 rounded-2xl shadow-sm">
                          <h5 className="text-indigo-800 font-bold text-xs flex items-center gap-2 mb-3">
                            <Search className="w-4 h-4" /> SEO Integration
                          </h5>
                          <p className="text-indigo-700 text-xs leading-relaxed font-medium">
                            By using Next.js SSR, your data is rendered on the server, allowing crawlers to see your content instantly. This significantly improves search rankings compared to standard CSR.
                          </p>
                        </div>
                        
                        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
                          <h5 className="text-slate-900 font-bold text-xs mb-4 flex items-center gap-2">
                            <ExternalLink className="w-3 h-3 text-indigo-600" /> Mastery Resources
                          </h5>
                          <div className="space-y-2">
                            <a href="https://nextjs.org/docs" target="_blank" className="flex items-center justify-between text-[11px] p-2.5 bg-slate-50 hover:bg-indigo-50 rounded-lg text-slate-700 hover:text-indigo-700 font-bold transition-all border border-slate-100">
                              Next.js Official Docs <ChevronRight className="w-3 h-3" />
                            </a>
                            <a href="https://zustand-demo.pmnd.rs/" target="_blank" className="flex items-center justify-between text-[11px] p-2.5 bg-slate-50 hover:bg-indigo-50 rounded-lg text-slate-700 hover:text-indigo-700 font-bold transition-all border border-slate-100">
                              Zustand State Guide <ChevronRight className="w-3 h-3" />
                            </a>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="bg-white rounded-3xl border-2 border-dashed border-slate-200 p-24 text-center">
                  <div className="bg-indigo-50 w-20 h-20 rounded-3xl flex items-center justify-center mx-auto mb-6 transform rotate-3">
                    <Globe className="w-10 h-10 text-indigo-500" />
                  </div>
                  <h3 className="text-2xl font-bold text-slate-900 tracking-tight">Modern State Control</h3>
                  <p className="text-slate-500 mt-2 max-w-sm mx-auto leading-relaxed">The curriculum now includes Zustand for global state management. Select a phase to explore industrial full-stack patterns.</p>
                </div>
              )}
            </div>
          </div>
        )}

        {activeTab === 'code' && (
          <div className="grid grid-cols-1 gap-8 animate-slide-up">
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
              <div>
                <h2 className="text-3xl font-bold text-slate-900 tracking-tight">Modern Boilerplates</h2>
                <p className="text-slate-500 mt-1">Industrial config snippets for Next.js, Backend, and Global State.</p>
              </div>
              <div className="flex gap-2">
                <span className="bg-slate-900 text-white px-3 py-1.5 rounded-lg text-[10px] font-bold uppercase">v3.0 Ready</span>
              </div>
            </div>
            
            <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
              {Object.entries(BOILERPLATE_CODE).map(([key, file]) => (
                <div key={key} className="bg-slate-900 rounded-2xl overflow-hidden shadow-2xl border border-white/5 instructor-card">
                  <div className="bg-slate-800/80 px-6 py-4 flex items-center justify-between border-b border-white/5">
                    <div className="flex items-center gap-3">
                      <div className="p-1.5 bg-indigo-500/10 rounded-lg">
                        <FileCode className="w-4 h-4 text-indigo-400" />
                      </div>
                      <span className="text-xs font-mono font-bold text-slate-300 tracking-wider">{file.filename}</span>
                    </div>
                    <button 
                      onClick={() => copyToClipboard(file.content, key)}
                      className="text-slate-400 hover:text-white transition-colors p-2 hover:bg-white/5 rounded-lg"
                    >
                      {copiedKey === key ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                    </button>
                  </div>
                  <div className="p-8">
                    <pre className="text-[11px] font-mono text-indigo-200/90 leading-relaxed overflow-x-auto max-h-[400px] custom-scrollbar scrollbar-thumb-slate-700">
                      {file.content}
                    </pre>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'chat' && (
          <div className="max-w-4xl mx-auto bg-white rounded-[2rem] border border-slate-200 shadow-2xl overflow-hidden flex flex-col h-[75vh] animate-slide-up">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-white to-indigo-50/20">
              <div className="flex items-center gap-4">
                <div className="bg-indigo-600 p-3 rounded-2xl shadow-lg shadow-indigo-100">
                  <MessageSquare className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 text-lg">Infrastructure Expert Chat</h3>
                  <div className="flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                    <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Full-Stack Specialist</span>
                  </div>
                </div>
              </div>
              <Settings className="w-5 h-5 text-slate-400 cursor-pointer hover:text-indigo-600 transition-colors" />
            </div>

            <div className="flex-1 overflow-y-auto p-8 space-y-8 bg-slate-50/30 custom-scrollbar">
              {chatHistory.length === 0 && (
                <div className="text-center py-24 space-y-6">
                  <div className="bg-white w-24 h-24 rounded-[2rem] shadow-sm flex items-center justify-center mx-auto mb-4 border border-slate-100">
                    <Rocket className="w-10 h-10 text-indigo-600" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-slate-900 tracking-tight">Deploy with confidence</h3>
                    <p className="text-slate-500 mt-2 text-sm max-w-sm mx-auto leading-relaxed">I can guide you through Zustand implementation, Next.js hydration errors, or GitHub Actions pipelines.</p>
                  </div>
                  <div className="flex flex-wrap justify-center gap-2">
                    {["When to use Zustand vs Context?", "Fix Vercel deployment cache", "Explain MongoDB connection pooling"].map(q => (
                      <button 
                        key={q}
                        onClick={() => setUserInput(q)}
                        className="text-xs bg-white border border-slate-200 px-4 py-2 rounded-xl hover:border-indigo-300 hover:text-indigo-600 transition-all font-semibold shadow-sm"
                      >
                        {q}
                      </button>
                    ))}
                  </div>
                </div>
              )}
              {chatHistory.map((msg, i) => (
                <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[80%] p-5 rounded-3xl shadow-sm text-sm leading-relaxed ${
                    msg.role === 'user' 
                      ? 'bg-indigo-600 text-white rounded-tr-none font-medium' 
                      : 'bg-white border border-slate-100 text-slate-800 rounded-tl-none font-medium prose prose-sm'
                  }`}>
                    {msg.content}
                  </div>
                </div>
              ))}
              {isTyping && (
                <div className="flex justify-start">
                  <div className="bg-white p-5 rounded-3xl rounded-tl-none border border-slate-100 flex gap-1.5 shadow-sm">
                    <div className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce" />
                    <div className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce [animation-delay:0.2s]" />
                    <div className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce [animation-delay:0.4s]" />
                  </div>
                </div>
              )}
            </div>

            <div className="p-8 bg-white border-t border-slate-100">
              <form onSubmit={e => { e.preventDefault(); handleSendMessage(); }} className="flex gap-4">
                <input 
                  type="text"
                  value={userInput}
                  onChange={e => setUserInput(e.target.value)}
                  placeholder="Ask about Next.js, State, or DevOps..."
                  className="flex-1 bg-slate-50 border-slate-100 focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 rounded-2xl px-6 py-4 text-sm transition-all font-medium placeholder:text-slate-400 shadow-inner"
                />
                <button 
                  type="submit" 
                  disabled={!userInput.trim() || isTyping}
                  className="bg-indigo-600 text-white px-8 py-4 rounded-2xl font-bold text-sm shadow-xl shadow-indigo-200 hover:bg-indigo-700 disabled:opacity-50 transition-all active:scale-95 flex items-center gap-2"
                >
                  Consult <Search className="w-4 h-4" />
                </button>
              </form>
            </div>
          </div>
        )}
      </main>

      <footer className="bg-white border-t border-slate-200 py-10 mt-auto">
        <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-2">
             <div className="bg-slate-900 p-1.5 rounded-lg">
                <ShieldCheck className="w-4 h-4 text-white" />
             </div>
             <p className="text-sm font-bold text-slate-900 tracking-tight">Deployment Instructor Platform</p>
          </div>
          <div className="flex gap-8 text-xs font-bold text-slate-400 uppercase tracking-widest">
            <a href="#" className="hover:text-indigo-600 transition-colors">Documentation</a>
            <a href="#" className="hover:text-indigo-600 transition-colors">API Specs</a>
            <a href="#" className="hover:text-indigo-600 transition-colors">Lab Support</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
